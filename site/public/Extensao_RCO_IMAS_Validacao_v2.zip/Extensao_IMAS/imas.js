// Isolated-world adapter. No network writes, form submit, Save clicks or photo-upload clicks.
(() => {
  const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
  const visible=e=>!!(e.offsetWidth||e.offsetHeight||e.getClientRects().length);
  const definitions={
    code:[['codigo'],['id_ordem_servico']],type:[['tipo','o.s'],['tipo','os'],['tipo_os']],status:[['status']],
    openedDate:[['data','abertura']],openedTime:[['hora','abertura'],['data','abertura']],
    startDate:[['data','inicio','execucao']],startTime:[['hora','inicio'],['data','inicio','execucao']],
    endDate:[['data','prevista'],['data','conclusao']],endTime:[['hora','prevista'],['hora','conclusao'],['data','prevista']],
    creationJustification:[['justificativa','alteracao']],subject:[['assunto'],['solicitacao']],
    unit:[['local','unidade']],system:[['sistema']],environment:[['ambiente']],floor:[['pavimento']],
    ans:[['classificacao','ans']],ansJustification:[['justificativa','ans']],responsible:[['colaborador']],
    activation:[['acionamento']],clientReference:[['sistema','cliente']],clientCode:[['cod.','cliente'],['cod_cliente']],
    observation:[['observacao'],['observacoes']]
  };
  const kinds={code:['text','number'],type:['select'],status:['select'],openedDate:['date','text'],openedTime:['time'],startDate:['date','text'],startTime:['time'],endDate:['date','text'],endTime:['time'],creationJustification:['text','textarea'],subject:['text','textarea'],unit:['select'],system:['select'],environment:['text','textarea'],floor:['text','textarea'],ans:['select'],ansJustification:['text','textarea'],responsible:['select'],activation:['select','text','textarea'],clientReference:['text','number'],clientCode:['text','number'],observation:['textarea']};
  function labels(e){const linked=e.id?document.querySelector(`label[for="${CSS.escape(e.id)}"]`):null;return {direct:norm([linked?.textContent,e.getAttribute('aria-label'),e.placeholder].filter(Boolean).join(' ')),meta:norm(`${e.id} ${e.name}`),context:norm(e.parentElement?.textContent)};}
  function selector(e){if(e.id)return '#'+CSS.escape(e.id);if(e.name)return `${e.tagName.toLowerCase()}[name="${CSS.escape(e.name)}"]`;return '';}
  function field(key,optional=false){
    const candidates=[...document.querySelectorAll('input,select,textarea')].filter(e=>!e.disabled&&(!['hidden','submit','button','file','checkbox'].includes(e.type))&&!e.classList.contains('select-dropdown')&&(visible(e)||e.tagName==='SELECT'||(key==='observation'&&e.tagName==='TEXTAREA')));
    const rows=candidates.filter(e=>kinds[key].includes(e.tagName==='SELECT'?'select':e.type)).map(e=>{const c=labels(e);const score=Math.max(0,...definitions[key].map(terms=>{const has=s=>terms.every(t=>s.includes(norm(t)));return has(c.direct)?300+terms.length:has(c.meta)?200+terms.length:has(c.context)?100+terms.length:0;}));return {e,score};}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score);
    if(!rows.length){if(optional)return null;throw Error(`Campo não identificado: ${key}. Use Conferir campos na extensão.`);}
    if(rows.length>1&&rows[0].score===rows[1].score)throw Error(`Campo ambíguo: ${key}. Nenhum salvamento foi feito.`);
    return rows[0].e;
  }
  function read(e){return e.tagName==='SELECT'?e.selectedOptions[0]?.textContent||'':e.value;}
  function matches(a,b){const clean=s=>norm(s).replace(/^\d+\s*[-–:]\s*/,'');return clean(a)===clean(b);}
  function set(key,value,optional=false){const e=field(key,optional);if(!e)return;if(e.tagName==='SELECT'){
    const options=[...e.options].filter(o=>matches(o.textContent,value));if(options.length!==1)throw Error(`Opção ${value} não encontrada de forma única em ${key}.`);e.value=options[0].value;
    const visual=e.parentElement?.querySelector('input.select-dropdown');if(visual)visual.value=options[0].textContent;
  }else{const proto=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value').set.call(e,String(value));}
  e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));return e;}
  function split(value){const match=/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})$/.exec(value);if(!match)throw Error('Data/hora incompleta.');return [match[1],match[2]];}
  function dates(key,value){const [date,time]=split(value);const e=field(key+'Date');const display=e.type==='date'?date:date.split('-').reverse().join('/');set(key+'Date',display);set(key+'Time',time);}
  async function waitFor(fn){for(let i=0;i<30;i++){const result=fn();if(result)return result;await new Promise(r=>setTimeout(r,100));}throw Error('Campo ou janela não apareceu no IMAS.');}
  function exactButton(text,scope=document){const nodes=[...scope.querySelectorAll('button,a')].filter(visible).filter(e=>norm(e.textContent)===norm(text));if(nodes.length!==1)throw Error(`Botão ${text} não identificado de forma única.`);return nodes[0];}
  async function expand(text){const rows=[...document.querySelectorAll('a,button,legend,summary,div,span')].filter(visible).filter(e=>norm(e.textContent)===norm(text)).sort((a,b)=>a.querySelectorAll('*').length-b.querySelectorAll('*').length);if(!rows.length)throw Error(`Seção ${text} não encontrada.`);rows[0].click();await new Promise(r=>setTimeout(r,200));}
  async function client(fixed){
    const code=field('clientCode',true);if(code&&String(code.value)==='91')return;
    exactButton('Localizar').click();
    const search=await waitFor(()=>[...document.querySelectorAll('input')].find(e=>visible(e)&&/procurar por/.test(norm(e.placeholder||labels(e).context))));
    search.value='deposito';search.dispatchEvent(new Event('input',{bubbles:true}));exactButton('Pesquisar').click();
    const row=await waitFor(()=>[...document.querySelectorAll('tr')].find(e=>visible(e)&&norm(e.textContent).includes(norm(fixed.client))&&/\b91\b/.test(e.textContent)));
    const choices=[...row.querySelectorAll('button,a')].filter(visible);if(choices.length!==1)throw Error('Seleção do cliente ambígua. Escolha o código 91 manualmente.');choices[0].click();
    await waitFor(()=>field('clientCode',true)?.value==='91');
  }
  async function observations(value){
    let e=field('observation',true),editor=[...document.querySelectorAll('[contenteditable="true"],.note-editable')].filter(visible);
    if(!editor.length&&(!e||!visible(e))){await expand('Observações');e=field('observation',true);editor=[...document.querySelectorAll('[contenteditable="true"],.note-editable')].filter(visible);}
    if(editor.length>1)throw Error('Mais de um editor de observações encontrado.');
    if(!e&&!editor.length)throw Error('Editor de observações não identificado.');
    if(e)set('observation',value);
    if(editor.length){editor[0].textContent=value;editor[0].dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:value}));editor[0].dispatchEvent(new Event('change',{bubbles:true}));}
  }
  function expected(job){const r=job.report;return {status:job.phase==='criar'?job.fixed.status:'Concluída',creationJustification:job.phase==='criar'?job.fixed.creationJustification:job.fixed.completionJustification,environment:r.environment,floor:r.floor,...(job.phase==='criar'?{type:job.fixed.type,subject:r.imasSubject,unit:job.fixed.unit,system:r.imasSystem,ans:job.fixed.ans,ansJustification:job.fixed.ansJustification,responsible:job.responsible}:{}),...(r.imasActivation?{activation:r.imasActivation}:{}),...(r.imasClientReference?{clientReference:r.imasClientReference}:{})};}
  async function prepare(job){
    if(location.origin!=='https://admin.rcoengenharia.com')throw Error('Destino inválido.');
    if(job.saveAllowed!==false||job.photoUploadAllowed!==false||job.mode!=='validation')throw Error('Salvamento bloqueado durante validação.');
    const code=field('code',true);const urlNumber=new URL(location.href).searchParams.get('id_ordem_servico');
    if(job.phase==='criar'&&((urlNumber&&urlNumber!=='0')||(code&&code.value&&code.value!=='0')))throw Error('Este formulário já tem número. Abra Novo para não sobrescrever uma OS existente.');
    if(job.phase==='encerrar'&&urlNumber!==job.externalNumber)throw Error('A OS aberta não corresponde à OS da fila.');
    if(job.phase==='encerrar'&&matches(read(field('status')),'Concluída'))throw Error('Esta OS já está concluída no IMAS. Confira a baixa manualmente.');
    // Preflight every field before any values are changed.
    for(const key of Object.keys(expected(job)))field(key);
    for(const key of ['start','end',...(job.phase==='criar'?['opened']:[])]){field(key+'Date');field(key+'Time');}
    if(job.phase==='criar')await client(job.fixed);
    const values=expected(job);for(const [key,value]of Object.entries(values))set(key,value);
    const checkbox=[...document.querySelectorAll('input[type="checkbox"]')].filter(e=>norm(labels(e).direct+' '+labels(e).meta).includes('status'));if(checkbox.length>1)throw Error('Marcação de Status ambígua.');if(checkbox.length&&!checkbox[0].checked)checkbox[0].click();
    dates('start',job.report.executionStartedAt);dates('end',job.report.completedAt);if(job.phase==='criar')dates('opened',job.report.imasOpenedAt);
    await observations(job.report.observations);
    if(job.phase==='encerrar'){if(!document.querySelector('input[type="file"]'))await expand('Fotos');await waitFor(()=>document.querySelector('input[type="file"]'));}
    return {prepared:true,saveClicked:false,uploadClicked:false};
  }
  async function addPhoto({dataUrl,name,reset}){
    const inputs=[...document.querySelectorAll('input[type="file"]')];if(inputs.length!==1)throw Error('Campo de fotos ausente ou ambíguo.');const input=inputs[0];
    const match=/^data:image\/jpeg;base64,(.+)$/.exec(dataUrl);if(!match)throw Error('Foto inválida.');const bytes=Uint8Array.from(atob(match[1]),c=>c.charCodeAt(0));
    const transfer=new DataTransfer();if(!reset)for(const f of input.files)transfer.items.add(f);
    transfer.items.add(new File([bytes],name,{type:'image/jpeg'}));if(transfer.files.length>1&&!input.multiple)throw Error('O campo do IMAS aceita apenas uma foto. Confira o envio sequencial antes da validação.');
    // No change event: the site's event handler could upload immediately.
    input.files=transfer.files;return {selected:transfer.files.length,uploaded:false};
  }
  async function audit(job){const errors=[],fields={};for(const [key,value]of Object.entries(expected(job))){try{const actual=read(field(key));fields[key]=actual;if(!matches(actual,value))errors.push(key);}catch(e){errors.push(e.message);}}
    for(const key of ['start','end',...(job.phase==='criar'?['opened']:[])]){const value=key==='start'?job.report.executionStartedAt:key==='end'?job.report.completedAt:job.report.imasOpenedAt;const [date,time]=split(value);try{const dateElement=field(key+'Date');if(dateElement.value!==(dateElement.type==='date'?date:date.split('-').reverse().join('/')))errors.push(key+'Date');if(field(key+'Time').value!==time)errors.push(key+'Time');}catch(e){errors.push(e.message);}}
    const e=field('observation',true),editor=[...document.querySelectorAll('[contenteditable="true"],.note-editable')].filter(visible);if(e&&e.value!==job.report.observations)errors.push('observation');else if(!e&&editor[0]?.textContent!==job.report.observations)errors.push('observation');
    const photos=[...document.querySelectorAll('input[type="file"]')].reduce((total,input)=>total+input.files.length,0);if(job.phase==='encerrar'&&photos!==job.report.photos.length)errors.push('Quantidade de fotos selecionadas');
    return {ok:errors.length===0,errors,fields,photos,saveClicked:false,uploadClicked:false};
  }
  function inventory(){return Object.keys(definitions).map(key=>{try{const e=field(key);return {field:key,selector:selector(e),type:e.tagName==='SELECT'?'select':e.type,options:e.tagName==='SELECT'?[...e.options].map(o=>o.textContent):undefined};}catch(e){return {field:key,error:e.message};}});}
  globalThis.RcoImas={prepare,addPhoto,audit,inventory};
})();
