const status=document.getElementById('status'),jobs=document.getElementById('jobs'),prepare=document.getElementById('prepare');
async function call(action,data={}){const result=await chrome.runtime.sendMessage({action,...data});if(result.error)throw Error(result.error);return result;}
async function run(fn){try{status.textContent='Preparando...';await fn();}catch(e){status.textContent=e.message;}}
document.getElementById('load').onclick=()=>run(async()=>{const result=await call('queue');jobs.replaceChildren();for(const j of result.jobs){const option=document.createElement('option');option.value=j.publicId;option.textContent=`${j.reference} · ${j.phase}${j.ready?'':' · PENDENTE: '+j.errors.join(', ')}`;option.disabled=!j.ready;jobs.append(option);}jobs.selectedIndex=[...jobs.options].findIndex(o=>!o.disabled);prepare.disabled=!jobs.value;status.textContent=`${result.jobs.length} OS na fila. Selecione uma para revisar.`;});
jobs.onchange=()=>prepare.disabled=!jobs.value;
prepare.onclick=()=>run(async()=>{if(!jobs.value)return;status.textContent=(await call('preview',{publicId:jobs.value})).message;});
document.getElementById('inspect').onclick=()=>run(async()=>status.textContent=JSON.stringify((await call('inspect')).inventory,null,2));
document.getElementById('release').onclick=()=>run(async()=>{if(!confirm('A OS foi revisada? Liberar permite preparar outra, mas não salva nem descarta o formulário do IMAS.'))return;status.textContent=(await call('release')).message;});
document.getElementById('schedule').onchange=e=>run(async()=>status.textContent=(await call('schedule',{enabled:e.target.checked})).message);
run(async()=>{const result=await call('status');document.getElementById('schedule').checked=!!result.scheduleEnabled;status.textContent=result.pending?JSON.stringify(result.pending,null,2):'Nenhum teste em andamento. Gravação bloqueada.';});
