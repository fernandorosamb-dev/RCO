import {nextSlot,safeJob} from './schedule.js';
const RCO='https://rco-manutencao.fernandorosa-mb.chatgpt.site/';
const IMAS='https://admin.rcoengenharia.com/';
let running=false;
const wait=ms=>new Promise(r=>setTimeout(r,ms));
async function audit(kind,data={}){const {audit=[]}=await chrome.storage.local.get('audit');await chrome.storage.local.set({audit:[...audit,{at:new Date().toISOString(),kind,...data}].slice(-100)});}
async function rcoTab(){const tabs=await chrome.tabs.query({url:RCO+'*'});if(!tabs.length)throw Error('Abra o RCO e entre como Supervisor.');return tabs[0];}
async function message(tab,body){const result=await chrome.tabs.sendMessage(tab.id,body);if(result?.error)throw Error(result.error);if(!result||!('data'in result))throw Error('Recarregue o RCO após instalar a extensão.');return result.data;}
async function queue(){return message(await rcoTab(),{action:'fila'});}
async function imasTab(){const tabs=await chrome.tabs.query({url:IMAS+'*'});if(tabs.length!==1)throw Error('Mantenha uma única aba do IMAS aberta para o teste.');if(/login|index\.php/.test(tabs[0].url||''))throw Error('Entre no IMAS e abra o formulário da OS.');return tabs[0];}
async function loaded(id){for(let i=0;i<40;i++){const t=await chrome.tabs.get(id);if(t.status==='complete')return;await wait(250);}throw Error('O IMAS demorou para abrir.');}
async function engine(tab,operation,payload){await chrome.scripting.executeScript({target:{tabId:tab.id},files:['imas.js']});const [result]=await chrome.scripting.executeScript({target:{tabId:tab.id},func:async(op,data)=>{try{return {data:await globalThis.RcoImas[op](data)};}catch(e){return {error:e.message};}},args:[operation,payload??null]});if(result?.result?.error)throw Error(result.result.error);return result?.result?.data;}
// Keep the square white-margin format used by the existing 1.0.4 activator.
async function adjustPhoto(data){const blob=await(await fetch(data)).blob();const bitmap=await createImageBitmap(blob);try{const side=Math.min(1600,Math.max(bitmap.width,bitmap.height)),area=Math.round(side*.90),scale=Math.min(area/bitmap.width,area/bitmap.height),w=Math.round(bitmap.width*scale),h=Math.round(bitmap.height*scale);const canvas=new OffscreenCanvas(side,side),ctx=canvas.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,side,side);ctx.drawImage(bitmap,Math.round((side-w)/2),Math.round((side-h)/2),w,h);const output=await canvas.convertToBlob({type:'image/jpeg',quality:0.86});const bytes=new Uint8Array(await output.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=32768)binary+=String.fromCharCode(...bytes.subarray(i,i+32768));return 'data:image/jpeg;base64,'+btoa(binary);}finally{bitmap.close();}}

async function preview(publicId){
  if(running)throw Error('Já há um teste em andamento.');running=true;
  try{
    const {pending}=await chrome.storage.local.get('pending');if(pending)throw Error('Há uma OS preparada aguardando revisão. Libere esse teste na extensão antes de preparar outra.');
    const data=await queue();const job=safeJob(data.jobs.find(j=>j.publicId===publicId));const tab=await imasTab();
    // Reserve before touching the form. A worker restart does not lose the lock.
    await chrome.storage.local.set({pending:{publicId,reference:job.reference,phase:job.phase,tabId:tab.id,at:new Date().toISOString(),state:'preparando'}});
    if(job.phase==='encerrar'){
      const url=new URL(tab.url);if(url.pathname!=='/ordem_servico_form.php'||url.searchParams.get('id_ordem_servico')!==job.externalNumber)throw Error(`Abra manualmente a OS ${job.externalNumber} no IMAS antes do teste. Nenhuma outra OS será alterada.`);
    }else if(!String(tab.url).includes('ordem_servico_form.php'))throw Error('No IMAS, vá em Manutenção → Ordens pendentes → Novo. Depois repita o teste.');
    await loaded(tab.id);
    await engine(tab,'prepare',job);
    if(job.phase==='encerrar'){
      const rt=await rcoTab();for(const [index,photo]of job.report.photos.entries()){
        const original=await message(rt,{action:'foto',url:photo.url});const dataUrl=await adjustPhoto(original);
        await engine(tab,'addPhoto',{dataUrl,name:`OS_${job.externalNumber}_Foto_${String(index+1).padStart(2,'0')}.jpg`,reset:index===0});
      }
    }
    const formAudit=await engine(tab,'audit',job);if(!formAudit.ok)throw Error('Confira os campos que divergiram: '+formAudit.errors.join('; '));
    await chrome.storage.local.set({pending:{publicId,reference:job.reference,phase:job.phase,tabId:tab.id,at:new Date().toISOString(),state:'aguardando validação',audit:formAudit}});
    await chrome.tabs.update(tab.id,{active:true});await audit('teste-preparado',{publicId,reference:job.reference,phase:job.phase,fields:formAudit.fields,photos:formAudit.photos});
    return {message:job.phase==='criar'?'OS preenchida como Aberta. Confira tudo no IMAS. A extensão NÃO clicou em Salvar.':'Encerramento preparado. Fotos apenas selecionadas, sem enviar arquivos. Confira os campos. A extensão NÃO clicou em Salvar nem marcou baixa no app.'};
  }catch(e){await audit('falha',{message:e.message});throw e;}finally{running=false;}
}
async function schedule(){const {scheduleEnabled=false}=await chrome.storage.local.get('scheduleEnabled');await chrome.alarms.clear('rco-imas');if(scheduleEnabled)await chrome.alarms.create('rco-imas',{when:nextSlot()});}
async function tick(){
  try{const data=await queue();const jobs=data.jobs.map(j=>({publicId:j.publicId,reference:j.reference,phase:j.phase,ready:j.ready,errors:j.errors}));await chrome.storage.local.set({lastQueue:jobs,lastScheduleAt:new Date().toISOString()});await audit('fila-agendada',{total:jobs.length,ready:jobs.filter(j=>j.ready).length});await chrome.action.setBadgeText({text:String(jobs.filter(j=>j.ready).length)});await chrome.action.setBadgeBackgroundColor({color:'#d97706'});
  }catch(e){await audit('agenda-bloqueada',{message:e.message});await chrome.action.setBadgeText({text:'!'});}finally{await schedule();}
}
chrome.alarms.onAlarm.addListener(alarm=>{if(alarm.name==='rco-imas')tick();});
chrome.runtime.onInstalled.addListener(()=>schedule());chrome.runtime.onStartup.addListener(()=>schedule());
chrome.runtime.onMessage.addListener((m,sender,respond)=>{
  const fromPopup=!sender.tab&&sender.id===chrome.runtime.id;
  const fromRco=sender.id===chrome.runtime.id&&sender.tab?.url?.startsWith(RCO);
  if(!fromPopup&&!fromRco)return;
  if(!fromPopup&&!['preview'].includes(m.action))return;
  (async()=>{
    if(m.action==='queue'){const data=await queue();return {jobs:data.jobs.map(j=>({publicId:j.publicId,reference:j.reference,phase:j.phase,ready:j.ready,errors:j.errors}))};}
    if(m.action==='preview')return preview(m.publicId);
    if(m.action==='status')return chrome.storage.local.get(['pending','scheduleEnabled','lastScheduleAt','audit']);
    if(m.action==='release'){if(running)throw Error('Aguarde o teste terminar.');await chrome.storage.local.remove('pending');await audit('teste-liberado');return {message:'Teste liberado. A extensão não salvou nem marcou baixa.'};}
    if(m.action==='schedule'){await chrome.storage.local.set({scheduleEnabled:m.enabled===true});await schedule();return {message:m.enabled?'Consulta da fila às 11h e 16h ativada. Gravação continua bloqueada.':'Consulta agendada desativada.'};}
    if(m.action==='inspect'){const tab=await imasTab();return {inventory:await engine(tab,'inventory')};}
    throw Error('Ação não disponível no modo de validação.');
  })().then(respond).catch(e=>respond({error:e.message,message:'Erro: '+e.message}));return true;
});

// Re-create a missing alarm after a service-worker restart, without replaying missed batches.
(async()=>{const {scheduleEnabled}=await chrome.storage.local.get('scheduleEnabled');if(scheduleEnabled&&!await chrome.alarms.get('rco-imas'))await schedule();})().catch(e=>audit('agenda-bloqueada',{message:e.message}));
