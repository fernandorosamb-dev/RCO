export function nextSlot(now=new Date()) {
  // Brazil wall clock independent of the computer's configured timezone.
  const parts=new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  for(const hour of [11,16]){const slot=new Date(`${parts}T${String(hour).padStart(2,'0')}:00:00-03:00`);if(slot>now)return slot.getTime();}
  return new Date(`${parts}T11:00:00-03:00`).getTime()+86400000;
}
export function safeJob(job) {
  if(!job||!job.ready||job.errors?.length)throw Error('Corrija os campos pendentes da OS no app.');
  if(job.saveAllowed!==false||job.photoUploadAllowed!==false||job.mode!=='validation')throw Error('Este pacote aceita apenas modo de validação.');
  if(!['criar','encerrar'].includes(job.phase))throw Error('Etapa inválida.');
  if(job.phase==='criar'&&job.externalNumber)throw Error('OS já vinculada. Não criar novamente.');
  if(job.phase==='encerrar'&&!/^\d+$/.test(job.externalNumber||''))throw Error('Vincule o número do IMAS antes de encerrar.');
  return job;
}
