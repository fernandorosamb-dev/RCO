(() => {
  const RCO='https://rco-manutencao.fernandorosa-mb.chatgpt.site';
  if(location.origin!==RCO)return;
  async function get(path,body) {
    const response=await fetch(path,{cache:'no-store',...(body?{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}:{})});
    const result=await response.json();if(!response.ok)throw Error(result.error||'Entre como Supervisor no RCO.');return result;
  }
  chrome.runtime.onMessage.addListener((message,sender,respond)=>{
    if(sender.id!==chrome.runtime.id||!['fila','foto'].includes(message.action))return;
    (async()=>{
      if(message.action==='fila')return get('/api/imas/queue');
      // Only the authenticated photo endpoint; never arbitrary URLs supplied by pages.
      if(!/^\/api\/photos\/[a-zA-Z0-9-]+$/.test(message.url))throw Error('Endereço de foto inválido.');
      const response=await fetch(message.url,{cache:'no-store'});if(!response.ok)throw Error('Foto não disponível.');
      const blob=await response.blob();if(blob.type!=='image/jpeg')throw Error('A evidência não é JPEG.');
      return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(reader.result);reader.onerror=reject;reader.readAsDataURL(blob);});
    })().then(data=>respond({data})).catch(e=>respond({error:e.message}));return true;
  });
  document.addEventListener('rco-imas-preview',event=>{
    const publicId=event.detail?.publicId;if(typeof publicId!=='string'||!/^[-a-zA-Z0-9]+$/.test(publicId))return;
    chrome.runtime.sendMessage({action:'preview',publicId}).then(result=>{
      const box=document.createElement('div');box.setAttribute('role','status');box.style.cssText='position:fixed;bottom:16px;left:16px;right:16px;z-index:9999;background:#173f67;color:white;padding:16px;border-radius:12px;';box.textContent=result?.message||'Confira a extensão.';box.onclick=()=>box.remove();document.body.append(box);setTimeout(()=>box.remove(),20000);
    });
  });
})();
