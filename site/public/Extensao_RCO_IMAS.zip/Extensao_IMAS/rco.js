chrome.runtime.onMessage.addListener((m,s,res)=>{(async()=>{
 if(m.acao==='relatorios'){const r=await fetch('/api/reports',{cache:'no-store'});if(!r.ok)throw Error('Entre como Supervisor no site RCO.');return await r.json();}
 if(m.acao==='foto'){const r=await fetch(m.url);if(!r.ok)throw Error('Foto não encontrada.');const b=await r.blob();return await new Promise((ok,fail)=>{const f=new FileReader();f.onload=()=>ok(f.result);f.onerror=fail;f.readAsDataURL(b)});}
 if(m.acao==='baixada'){const r=await fetch('/api/reports/downloaded',{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({publicId:m.publicId})});if(!r.ok)throw Error('Não foi possível marcar a OS como baixada.');return {ok:true};}
})().then(res).catch(e=>res({erro:e.message}));return true;});
