const status=document.getElementById('status');
async function iniciar(modo){
 if(modo==='massa'&&!confirm('Todas as OS aguardando baixa serão preenchidas, terão as fotos anexadas, serão salvas no IMAS e marcadas como baixadas. Continuar?'))return;
 status.textContent='Preparando...';
 try{const r=await chrome.runtime.sendMessage({acao:'iniciar',modo});status.textContent=r?.mensagem||'Processo encerrado.';}catch(e){status.textContent='Erro: '+e.message;}
}
document.getElementById('testar').onclick=()=>iniciar('teste');
document.getElementById('massa').onclick=()=>iniciar('massa');
