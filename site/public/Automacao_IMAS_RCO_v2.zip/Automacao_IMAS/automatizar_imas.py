from __future__ import annotations

import json
import time
import unicodedata
from pathlib import Path
from tkinter import Tk, messagebox
from urllib.parse import urljoin

import requests
from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait

BASE = Path(__file__).resolve().parent
OS_TESTE = (BASE / "numero_os.txt").read_text(encoding="utf-8").strip()
SITE_RCO = "https://rco-manutencao.fernandorosa-mb.chatgpt.site"
URL_IMAS = "https://admin.rcoengenharia.com/ordem_servico_form.php?id_ordem_servico={}"
JUSTIFICATIVA = "Ajuste de data da execução"
PERFIL = BASE / "perfil_chrome_imas"
PASTA_FOTOS = BASE / "fotos_baixadas"
DIAGNOSTICO = BASE / "diagnostico_imas.json"


def janela(metodo, titulo: str, texto: str):
    root = Tk(); root.withdraw(); root.attributes("-topmost", True)
    resposta = metodo(titulo, texto, parent=root)
    root.destroy()
    return resposta


def avisar(titulo: str, texto: str) -> None:
    janela(messagebox.showinfo, titulo, texto)


def perguntar(titulo: str, texto: str) -> bool:
    return bool(janela(messagebox.askyesno, titulo, texto))


def normalizar(texto: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", str(texto).lower()) if unicodedata.category(c) != "Mn")


def visivel(elemento) -> bool:
    try:
        return elemento.is_displayed() and elemento.is_enabled()
    except Exception:
        return False


def campos_visiveis(driver):
    return [e for e in driver.find_elements(By.CSS_SELECTOR, "input, textarea, select")
            if visivel(e) and (e.get_attribute("type") or "").lower() not in {"hidden", "submit", "button", "file"}]


def texto_contexto(driver, elemento) -> str:
    return driver.execute_script("""
      const e=arguments[0], parts=[e.id,e.name,e.placeholder,e.getAttribute('aria-label'),e.type];
      let p=e; for(let i=0;i<3&&p;i++,p=p.parentElement) parts.push(p.innerText||'');
      if(e.id){const l=document.querySelector(`label[for="${CSS.escape(e.id)}"]`);if(l)parts.push(l.innerText||'');}
      return parts.filter(Boolean).join(' ');
    """, elemento)


def localizar_campo(driver, grupos_tokens: list[list[str]], tipos: set[str] | None = None):
    candidatos = []
    for indice, elemento in enumerate(campos_visiveis(driver)):
        tipo = (elemento.get_attribute("type") or elemento.tag_name).lower()
        if tipos and tipo not in tipos:
            continue
        contexto = normalizar(texto_contexto(driver, elemento))
        melhor = 0
        for tokens in grupos_tokens:
            pontos = sum(1 for token in tokens if normalizar(token) in contexto)
            melhor = max(melhor, 100 + pontos if pontos == len(tokens) else pontos)
        if melhor:
            candidatos.append((melhor, -indice, elemento))
    if not candidatos:
        return None
    candidatos.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return candidatos[0][2]


def definir_valor(driver, elemento, valor: str) -> None:
    tipo = (elemento.get_attribute("type") or "text").lower()
    convertido = valor
    if tipo == "date":
        dia, mes, ano = valor.split("/"); convertido = f"{ano}-{mes}-{dia}"
    driver.execute_script("""
      const e=arguments[0],v=arguments[1];
      const proto=e.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
      const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
      if(setter)setter.call(e,v);else e.value=v;
      e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));e.blur();
    """, elemento, convertido)


def preencher(driver, nome: str, valor: str, tokens, tipos=None, obrigatorio=True):
    campo = localizar_campo(driver, tokens, tipos)
    if not campo:
        if obrigatorio:
            raise RuntimeError(f"Campo não localizado: {nome}")
        return False
    definir_valor(driver, campo, valor); print(f"OK - {nome}"); return True


def clicar_texto(driver, textos: list[str], obrigatorio=False):
    alvos = [normalizar(t) for t in textos]
    for e in driver.find_elements(By.XPATH, "//*[self::button or self::a or self::div or self::span or self::label]"):
        try:
            txt = normalizar(e.text.strip())
            if visivel(e) and txt and any(a == txt or a in txt for a in alvos):
                driver.execute_script("arguments[0].scrollIntoView({block:'center'});arguments[0].click();", e)
                time.sleep(1); return True
        except Exception:
            continue
    if obrigatorio:
        raise RuntimeError(f"Botão/seção não localizado: {textos[0]}")
    return False


def sessao_do_chrome(driver) -> requests.Session:
    sessao = requests.Session()
    sessao.headers.update({"User-Agent": driver.execute_script("return navigator.userAgent")})
    for cookie in driver.get_cookies():
        sessao.cookies.set(cookie["name"], cookie["value"], domain=cookie.get("domain"), path=cookie.get("path", "/"))
    return sessao


def carregar_relatorios(driver) -> tuple[requests.Session, list[dict]]:
    driver.get(SITE_RCO); time.sleep(2)
    sessao = sessao_do_chrome(driver)
    if not sessao.get(f"{SITE_RCO}/api/auth/me", timeout=30).ok:
        avisar("Login no site RCO", "Faça o login de Supervisor no site RCO.\n\nDepois que o painel aparecer, clique em OK aqui.")
        sessao = sessao_do_chrome(driver)
    resposta = sessao.get(f"{SITE_RCO}/api/reports", timeout=60)
    if resposta.status_code == 401:
        raise RuntimeError("O login de Supervisor no site RCO não foi concluído.")
    resposta.raise_for_status()
    relatorios = [r for r in resposta.json().get("reports", []) if r.get("origin") == "sistema"]
    relatorios.sort(key=lambda r: int(r["osNumber"]) if str(r.get("osNumber", "")).isdigit() else 999999999)
    return sessao, relatorios


def separar_data_hora(valor: str) -> tuple[str, str]:
    texto = str(valor or "")
    if len(texto) < 16 or "T" not in texto:
        raise RuntimeError(f"Data inválida no relatório: {texto or 'não informada'}")
    ano, mes, dia = texto[:10].split("-")
    return f"{dia}/{mes}/{ano}", texto[11:16]


def dados_do_relatorio(relatorio: dict) -> dict[str, str]:
    inicio_data, inicio_hora = separar_data_hora(relatorio.get("executionStartedAt", ""))
    fim_data, fim_hora = separar_data_hora(relatorio.get("completedAt", ""))
    dados = {"data_inicio": inicio_data, "hora_inicio": inicio_hora, "data_conclusao": fim_data,
             "hora_conclusao": fim_hora, "justificativa": JUSTIFICATIVA,
             "ambiente": str(relatorio.get("environment", "")).strip(),
             "pavimento": str(relatorio.get("floor", "")).strip(),
             "observacao": str(relatorio.get("observations", "")).strip()}
    if not dados["ambiente"] or not dados["pavimento"] or not dados["observacao"]:
        raise RuntimeError("Relatório sem Ambiente, Pavimento ou Observação.")
    return dados


def baixar_fotos(sessao: requests.Session, relatorio: dict) -> list[Path]:
    numero = str(relatorio["osNumber"]); pasta = PASTA_FOTOS / f"OS_{numero}"
    pasta.mkdir(parents=True, exist_ok=True); fotos = []
    for indice, foto in enumerate(relatorio.get("photos", []), start=1):
        arquivo = pasta / f"OS_{numero}_Foto_{indice:02d}.jpg"
        resposta = sessao.get(urljoin(SITE_RCO, str(foto.get("url", ""))), timeout=120)
        resposta.raise_for_status(); arquivo.write_bytes(resposta.content); fotos.append(arquivo)
    if not fotos:
        raise RuntimeError("Relatório sem fotos.")
    return fotos


def abrir_os(driver, espera, numero: str) -> None:
    url = URL_IMAS.format(numero); driver.get(url)
    if "login" in driver.current_url.lower():
        avisar("Login no IMAS", "Faça o login no IMAS.\n\nDepois que a página inicial abrir, clique em OK aqui.")
        driver.get(url)
    try:
        espera.until(lambda d: numero in d.page_source)
    except TimeoutException:
        raise RuntimeError("A página da OS não abriu. Confirme o login no IMAS.")


def anexar_fotos(driver, fotos: list[Path]) -> None:
    clicar_texto(driver, ["Fotos", "Foto"]); time.sleep(1)
    uploads = [e for e in driver.find_elements(By.CSS_SELECTOR, "input[type='file']") if e.is_enabled()]
    if not uploads:
        raise RuntimeError("Campo para anexar fotos não localizado.")
    caminhos = [str(p.resolve()) for p in fotos]
    if uploads[0].get_attribute("multiple") is not None:
        uploads[0].send_keys("\n".join(caminhos))
    else:
        for caminho in caminhos:
            uploads = [e for e in driver.find_elements(By.CSS_SELECTOR, "input[type='file']") if e.is_enabled()]
            uploads[-1].send_keys(caminho); time.sleep(1)


def preencher_os(driver, dados: dict[str, str], fotos: list[Path]) -> None:
    preencher(driver, "Data de início", dados["data_inicio"], [["data", "inicio", "execucao"]], {"date", "text"})
    preencher(driver, "Hora de início", dados["hora_inicio"], [["hora", "inicio"], ["inicio", "execucao"]], {"time", "text"})
    preencher(driver, "Data de conclusão", dados["data_conclusao"], [["data", "conclusao"], ["data", "prevista"]], {"date", "text"})
    preencher(driver, "Hora de conclusão", dados["hora_conclusao"], [["hora", "conclusao"], ["hora", "prevista"]], {"time", "text"})
    time.sleep(1.5)
    preencher(driver, "Justificativa", dados["justificativa"], [["justific"]], {"text"}, obrigatorio=False)
    preencher(driver, "Ambiente", dados["ambiente"], [["ambiente"]], {"text"})
    preencher(driver, "Pavimento", dados["pavimento"], [["pavimento"]], {"text"})
    clicar_texto(driver, ["Observações", "Observacao"]); time.sleep(1)
    preencher(driver, "Observação", dados["observacao"], [["observacao"], ["descricao"]], {"textarea", "text"})
    anexar_fotos(driver, fotos)


def marcar_baixada(sessao: requests.Session, relatorio: dict) -> None:
    resposta = sessao.patch(f"{SITE_RCO}/api/reports/downloaded", json={"publicId": relatorio["publicId"]}, timeout=30)
    resposta.raise_for_status()


def salvar_diagnostico(driver, erro: Exception, numero: str = "") -> None:
    dados = {"os": numero, "erro": str(erro), "url": driver.current_url, "titulo": driver.title, "campos": []}
    for e in driver.find_elements(By.CSS_SELECTOR, "input, textarea, select, button"):
        try:
            dados["campos"].append({"tag": e.tag_name, "type": e.get_attribute("type"), "id": e.get_attribute("id"),
              "name": e.get_attribute("name"), "placeholder": e.get_attribute("placeholder"),
              "texto": e.text[:200], "visivel": e.is_displayed()})
        except Exception:
            pass
    DIAGNOSTICO.write_text(json.dumps(dados, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> int:
    opcoes = webdriver.ChromeOptions(); opcoes.add_argument(f"--user-data-dir={PERFIL}"); opcoes.add_argument("--start-maximized")
    opcoes.add_experimental_option("excludeSwitches", ["enable-automation"])
    driver = webdriver.Chrome(options=opcoes); espera = WebDriverWait(driver, 30)
    falhas, concluidas = [], []
    try:
        sessao, relatorios = carregar_relatorios(driver)
        em_massa = perguntar("Modo de execução", f"Deseja processar TODAS as {len(relatorios)} OS aguardando baixa?\n\nSIM = todas em massa\nNÃO = somente a OS de teste {OS_TESTE}")
        selecionados = relatorios if em_massa else [r for r in relatorios if str(r.get("osNumber")) == OS_TESTE]
        if not selecionados:
            raise RuntimeError("Nenhuma OS correspondente foi encontrada aguardando baixa.")
        total_fotos = sum(len(r.get("photos", [])) for r in selecionados)
        if not perguntar("Confirmar preenchimento", f"Serão preenchidas {len(selecionados)} OS e enviadas {total_fotos} fotos ao IMAS.\n\nDeseja continuar?"):
            return 0
        for indice, relatorio in enumerate(selecionados, start=1):
            numero = str(relatorio["osNumber"])
            try:
                print(f"\n[{indice}/{len(selecionados)}] Processando OS {numero}")
                fotos = baixar_fotos(sessao, relatorio); abrir_os(driver, espera, numero)
                preencher_os(driver, dados_do_relatorio(relatorio), fotos); driver.execute_script("window.scrollTo(0,0)")
                autorizado = em_massa or perguntar(f"Salvar OS {numero}?", "Confira o relatório no IMAS. Você autoriza clicar em SALVAR agora?")
                if not autorizado:
                    avisar("Teste não salvo", "Os dados continuam na tela e a OS não foi marcada como baixada."); continue
                clicar_texto(driver, ["Salvar"], obrigatorio=True); time.sleep(2)
                marcar_baixada(sessao, relatorio); concluidas.append(numero); print(f"CONCLUÍDA - OS {numero}")
            except Exception as erro:
                falhas.append(f"OS {numero}: {erro}"); salvar_diagnostico(driver, erro, numero); print(f"FALHA - OS {numero}: {erro}")
                if not em_massa:
                    raise
        resumo = f"Concluídas: {len(concluidas)}"
        if falhas:
            resumo += f"\nCom falha: {len(falhas)}\n\n" + "\n".join(falhas[:8])
        avisar("Processamento encerrado", resumo)
        return 0 if not falhas else 1
    except Exception as erro:
        salvar_diagnostico(driver, erro); avisar("Automação interrompida", f"{erro}\n\nEnvie diagnostico_imas.json no ChatGPT para ajuste."); return 1
    finally:
        input("\nPressione ENTER para encerrar (o Chrome permanecerá aberto)...")


if __name__ == "__main__":
    raise SystemExit(main())
