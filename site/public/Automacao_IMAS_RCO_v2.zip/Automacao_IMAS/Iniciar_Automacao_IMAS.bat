@echo off
cd /d "%~dp0"
title Automacao IMAS - RCO

where py >nul 2>nul
if errorlevel 1 goto SEM_PYTHON

echo Preparando o automatizador. Aguarde...
py -m pip install --disable-pip-version-check selenium requests
if errorlevel 1 goto ERRO_INSTALACAO

echo Abrindo a automacao...
py "%~dp0automatizar_imas.py"
goto FIM

:SEM_PYTHON
echo Python nao foi encontrado neste computador.
echo Envie uma foto desta tela no ChatGPT.
goto FIM

:ERRO_INSTALACAO
echo Nao foi possivel preparar os componentes da automacao.
echo Envie uma foto desta tela no ChatGPT.

:FIM
pause
