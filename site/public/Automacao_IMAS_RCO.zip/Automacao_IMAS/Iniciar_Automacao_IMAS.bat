@echo off
chcp 65001 >nul
title Automação IMAS - RCO
cd /d "%~dp0"

where py >nul 2>nul
if errorlevel 1 (
  echo O Python não foi encontrado neste computador.
  echo Instale o Python pelo site python.org e marque a opção "Add Python to PATH".
  pause
  exit /b 1
)

echo Preparando o automatizador...
py -m pip install --disable-pip-version-check --quiet selenium requests
if errorlevel 1 (
  echo Não foi possível instalar o componente Selenium.
  pause
  exit /b 1
)

py "%~dp0automatizar_imas.py"
pause
